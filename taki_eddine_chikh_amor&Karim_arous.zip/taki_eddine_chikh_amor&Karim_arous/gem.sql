-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : Dim 24 jan. 2021 à 22:09
-- Version du serveur :  10.4.14-MariaDB
-- Version de PHP : 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gem`
--

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `adresse` text NOT NULL,
  `tel` varchar(20) NOT NULL,
  `fax` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `telcontact` varchar(20) NOT NULL,
  `valsync` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`id`, `nom`, `adresse`, `tel`, `fax`, `email`, `contact`, `telcontact`, `valsync`) VALUES
(1, 'société 1', '01 Rue ghazela', '91564231', '91564231', 'société1@gmail.com', 'med ali', '22559462', 0);

-- --------------------------------------------------------

--
-- Structure de la table `contrats`
--

CREATE TABLE `contrats` (
  `id` int(11) NOT NULL,
  `datedebut` date NOT NULL,
  `datefin` date NOT NULL,
  `redevence` decimal(10,0) NOT NULL,
  `client_id` int(11) NOT NULL,
  `valsync` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `employes`
--

CREATE TABLE `employes` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `actif` tinyint(1) NOT NULL,
  `valsync` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `employes`
--

INSERT INTO `employes` (`id`, `login`, `pwd`, `prenom`, `nom`, `email`, `actif`, `valsync`) VALUES
(1, 'majdi', 'bm12345', 'boulabiar', 'majdi', 'boulabiar.mejdi@gmail.com', 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `employes_interventions`
--

CREATE TABLE `employes_interventions` (
  `id` int(11) NOT NULL,
  `employe_id` int(11) NOT NULL,
  `intervention_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `nom` text NOT NULL,
  `img` longblob NOT NULL,
  `dateCapture` date NOT NULL,
  `intervention_id` int(11) NOT NULL,
  `valsync` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `interventions`
--

CREATE TABLE `interventions` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `datedebut` date NOT NULL,
  `datefin` date NOT NULL,
  `heuredebutplan` time NOT NULL,
  `heurefinplan` time NOT NULL,
  `commentaires` text NOT NULL,
  `dateplanification` date NOT NULL,
  `heuredebuteffect` time NOT NULL,
  `heurefineffect` time NOT NULL,
  `terminee` tinyint(1) NOT NULL,
  `dateterminaison` date NOT NULL,
  `validee` tinyint(1) NOT NULL,
  `datevalidation` date NOT NULL,
  `priorite_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `valsync` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `interventions`
--

INSERT INTO `interventions` (`id`, `titre`, `datedebut`, `datefin`, `heuredebutplan`, `heurefinplan`, `commentaires`, `dateplanification`, `heuredebuteffect`, `heurefineffect`, `terminee`, `dateterminaison`, `validee`, `datevalidation`, `priorite_id`, `site_id`, `valsync`) VALUES
(1, 'Intervention mobile', '2020-10-05', '2020-10-05', '10:30:00', '12:00:00', 'vide', '2020-10-02', '09:30:00', '10:35:00', 1, '2020-12-31', 1, '2020-12-01', 1, 1, 0),
(2, 'Intervention mobile', '2020-10-05', '2020-10-05', '10:30:00', '12:00:00', 'vide', '2020-10-02', '09:30:00', '10:35:00', 1, '2020-12-31', 1, '2020-12-01', 1, 11, 0);

-- --------------------------------------------------------

--
-- Structure de la table `priorites`
--

CREATE TABLE `priorites` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `valsync` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `sites`
--

CREATE TABLE `sites` (
  `id` int(11) NOT NULL,
  `longitude` decimal(10,0) NOT NULL,
  `latitude` decimal(10,0) NOT NULL,
  `adresse` text NOT NULL,
  `rue` varchar(255) NOT NULL,
  `codepostal` int(4) NOT NULL,
  `ville` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `telcontact` varchar(20) NOT NULL,
  `client_id` int(11) NOT NULL,
  `valsync` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `sites`
--

INSERT INTO `sites` (`id`, `longitude`, `latitude`, `adresse`, `rue`, `codepostal`, `ville`, `contact`, `telcontact`, `client_id`, `valsync`) VALUES
(1, '1201201201', '1020120120', '01 Rue ghazela', 'Rue ghazela', 1002, 'ghazela', 'med ali', '22559462', 1, 0);

-- --------------------------------------------------------

--
-- Structure de la table `taches`
--

CREATE TABLE `taches` (
  `id` int(11) NOT NULL,
  `refernce` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `duree` decimal(10,0) NOT NULL,
  `prixheure` decimal(10,0) NOT NULL,
  `dateaction` date NOT NULL,
  `intervention_id` int(11) NOT NULL,
  `valsync` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `contrats`
--
ALTER TABLE `contrats`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `employes`
--
ALTER TABLE `employes`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `employes_interventions`
--
ALTER TABLE `employes_interventions`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `interventions`
--
ALTER TABLE `interventions`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `priorites`
--
ALTER TABLE `priorites`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `sites`
--
ALTER TABLE `sites`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `taches`
--
ALTER TABLE `taches`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `contrats`
--
ALTER TABLE `contrats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `employes`
--
ALTER TABLE `employes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `employes_interventions`
--
ALTER TABLE `employes_interventions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `interventions`
--
ALTER TABLE `interventions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `priorites`
--
ALTER TABLE `priorites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `sites`
--
ALTER TABLE `sites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `taches`
--
ALTER TABLE `taches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
