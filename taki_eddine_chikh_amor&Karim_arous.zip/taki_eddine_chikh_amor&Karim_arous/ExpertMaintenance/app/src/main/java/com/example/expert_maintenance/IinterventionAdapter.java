package com.example.expert_maintenance;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.textfield.TextInputLayout;

import java.util.List;
import java.util.Map;

public class IinterventionAdapter extends ArrayAdapter {
    private Dialog myDialog;
    Context context;
    int adapterResources;
    List<InterventionModel> listIntervention;
    CheckBox satusInterv;

    public IinterventionAdapter(@NonNull Context context, int resource, @NonNull List<InterventionModel> listIntervention) {
        super(context, resource, listIntervention);
        this.context = context;
        this.adapterResources = resource;
        this.listIntervention = listIntervention;
    }

    @Nullable
    @Override
    public Object getItem(int position) {
        return super.getItem(position);
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull final ViewGroup parent) {
        View view;
        LayoutInflater rowIflate = LayoutInflater.from(parent.getContext());
        view = rowIflate.inflate(adapterResources, parent, false);
        TextView nameInterv = (TextView) view.findViewById(R.id.intervention_name);
        TextView nameCompany = (TextView) view.findViewById(R.id.company_name);
        TextView adrCompany = (TextView) view.findViewById(R.id.adr_company);
        TextView heurInterv = (TextView) view.findViewById(R.id.heure_intervention);
        satusInterv = (CheckBox) view.findViewById(R.id.status_intervention);

        final InterventionModel intervention= listIntervention.get(position);
        nameInterv.setText(intervention.nameIntervention);
        nameCompany.setText(intervention.companyIntervention);
        adrCompany.setText(intervention.adrCompany);
        heurInterv.setText(intervention.timeIntervention);

        if(intervention.satusIntervention.equals("1")) {
            satusInterv.setChecked(true);
        }else satusInterv.setChecked(false);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, DetailInterventionActivity.class)
                        .putExtra("nameInterv", intervention.nameIntervention)
                        .putExtra("nameCompany", intervention.companyIntervention)
                        .putExtra("timeInterv", intervention.timeIntervention));
            }
        });

        //confirmation incheck status feedback
        /*final AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
        satusInterv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = (intervention.satusIntervention.toString());
                Toast.makeText(getContext(), s, Toast.LENGTH_LONG).show();
                intervention.satusIntervention="1";


                if(satusInterv.isChecked())showDialog2();
                else showDialog1(); }
        });*/
        return view;

    }

    private void showDialog1() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
        dialog.setTitle("Décocher ?");
        dialog.setMessage("Ete vous sure de vouloire décocher cette intervention ?");

        //Action add post
        dialog.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {satusInterv.setChecked(false); }

        });
        // Button close dialog
        dialog.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                satusInterv.setChecked(true);
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void showDialog2() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
        dialog.setTitle("Cocher ?");
        dialog.setMessage("Ete vous sure de vouloire cocher cette intervention ?");

        //Action ok
        dialog.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) { satusInterv.setChecked(true); }

        });
        // Button close dialog
        dialog.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                satusInterv.setChecked(false);
                dialog.dismiss();
            }
        });

        dialog.show();
    }
}
