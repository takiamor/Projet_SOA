package com.example.expert_maintenance;

public class InterventionModel {
    public String nameIntervention,companyIntervention,adrCompany,timeIntervention,satusIntervention;

    public InterventionModel(String nameIntervention, String companyIntervention, String adrCompany, String timeIntervention, String satusIntervention) {
        this.nameIntervention = nameIntervention;
        this.companyIntervention = companyIntervention;
        this.adrCompany = adrCompany;
        this.timeIntervention = timeIntervention;
        this.satusIntervention = satusIntervention;
    }
}
