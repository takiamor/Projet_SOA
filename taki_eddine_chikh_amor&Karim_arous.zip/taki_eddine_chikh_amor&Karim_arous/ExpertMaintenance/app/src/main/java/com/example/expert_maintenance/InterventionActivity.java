package com.example.expert_maintenance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InterventionActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    ImageView menuIcon;

    ListView listinterventions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intervention);

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);
        menuIcon = findViewById(R.id.menu_icon);
        navigationDrawer();

        listinterventions = findViewById(R.id.list_interventions);

        List<InterventionModel> listIntervention = new ArrayList<>();
        listIntervention.add((new InterventionModel("Intervention 1","Société 1","01 Rue ghazela 1","09:10-11:00","1")));
        listIntervention.add((new InterventionModel("Intervention 2","Société 2","01 Rue ghazela 2","11:10-12:30","0")));
        listIntervention.add((new InterventionModel("Intervention 3","Société 3","01 Rue ghazela 1","13:15-15:00","1")));

        IinterventionAdapter adapter = new IinterventionAdapter(InterventionActivity.this, R.layout.item_intervantion, listIntervention);
        listinterventions.setAdapter(adapter);

        //bg_selectInterventions bgs =new bg_selectInterventions(getApplicationContext());
        //bgs.execute();

    }
    private void navigationDrawer() {
        //Navigation Drawer
        navigationView.bringToFront();
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_intervention);
        //getSupportFragmentManager().beginTransaction().replace(R.id.container,new HomePatientFrag());

        menuIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerVisible(GravityCompat.START))
                    drawerLayout.closeDrawer(GravityCompat.START);
                else drawerLayout.openDrawer(GravityCompat.START);
            }

        });
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return true;
    }
/*
    private class bg_selectInterventions extends AsyncTask<String, Void, String> {
        Context context;
        AlertDialog dialog;

        public bg_selectInterventions(Context context) {
            this.context = context;
        }

        @Override
        protected void onPreExecute() { super.onPreExecute(); }

        @Override
        protected String doInBackground(String... strings) {
            String result = "";
            String connstr = "http://192.168.1.7/bentechprotv/getAllIntervention.php";
            URL url = null;
            try {
                url = new URL(connstr);
                HttpURLConnection http = (HttpURLConnection) url.openConnection();
                http.setDoInput(true);
                //http.setDoOutput(true);

                InputStream ips =  http.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(ips,"ISO-8859-1"));
                String ligne ="";
                while ((ligne = reader.readLine()) != null)
                {
                    result += ligne;
                }
                reader.close();
                ips.close();
                http.disconnect();
                return result;
            } catch (IOException e) {
                result = e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (!s.equals("")){

                // remplir le listView

                 //  Map : projection
                 //  String (le premier élément : clé)
                 //  String (le deuxième élément : valeur)


                List<Map<String, String>> data = new ArrayList<Map<String,String>>();
                ArrayList<Intervention> interventions = new ArrayList<>();
                try {
                    JSONArray jInterventionArray = new JSONArray(s);
                    for (int i = 0; i < jInterventionArray.length(); i++){
                        Map<String,String> datum = new HashMap<String,String>(7);
                        datum.put("id", jInterventionArray.optJSONObject(i).getString("id"));
                        datum.put("titre", jInterventionArray.optJSONObject(i).getString("titre"));
                        datum.put("datedebut", jInterventionArray.optJSONObject(i).getString("datedebut"));
                        datum.put("datefin", jInterventionArray.optJSONObject(i).getString("datefin"));
                        datum.put("heuredebutplan", jInterventionArray.optJSONObject(i).getString("heuredebutplan"));
                        datum.put("heurefinplan", jInterventionArray.optJSONObject(i).getString("heurefinplan"));
                        datum.put("terminee", jInterventionArray.optJSONObject(i).getString("terminee"));

                        data.add(datum);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                IinterventionAdapter adapter = new IinterventionAdapter(InterventionActivity.this, R.layout.item_intervantion, data);
                listinterventions.setAdapter(adapter);
            }
        }

    }*/
}