package com.example.expert_maintenance;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;

public class DetailInterventionActivity extends AppCompatActivity {
    ImageView backBtn;
    TabLayout tabLayout;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_intervention);

        //Recuper info de l'intervention...
        Intent i = getIntent();
        if (i.hasExtra("nameInterv")) {
            String str_nameInterv = i.getStringExtra("nameInterv");
            TextView nameInterv = findViewById(R.id.name_intervention);
            nameInterv.setText(str_nameInterv); }
        if (i.hasExtra("nameCompany")) {
            String str_nameCompany = i.getStringExtra("nameCompany");
            TextView nameCompany = findViewById(R.id.company_name);
            nameCompany.setText(str_nameCompany);}
        if (i.hasExtra("timeInterv")) {
            String str_timeInterv = i.getStringExtra("timeInterv");
            TextView timeInterv = findViewById(R.id.heure_intervention);
            timeInterv.setText(str_timeInterv);}

        //Action back button
        backBtn = findViewById(R.id.back_icon);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DetailInterventionActivity.this, InterventionActivity.class);
                startActivity(intent);
            }
        });

        tabLayout = findViewById(R.id.tab_layout);
        viewPager = findViewById(R.id.view_pager);
        getTabs();
    }
    public void getTabs(){
        final ViewPageAdapter viewPageAdapter = new ViewPageAdapter(getSupportFragmentManager());

        new Handler().post(new Runnable() {
            @Override
            public void run() {
                viewPageAdapter.addFragment(DetailsFragment.getInstance(),"Details");
                viewPageAdapter.addFragment(FichierFragment.getInstance(),"Fichier");
                viewPageAdapter.addFragment(SignatureFragment.getInstance(),"Signature");

                viewPager.setAdapter(viewPageAdapter);
                tabLayout.setupWithViewPager(viewPager);
            }
        });

    }
}